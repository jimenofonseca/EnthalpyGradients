# Enthalpy Gradients

Library for calculation of daily and hourly enthalpy gradients in buildings

## Cite

J.A. Fonseca and A. Schlueter, Daily enthalpy gradients and the effects of climate change on the thermal energy demand of buildings in the United States, Appl. Energy, vol. 262, no. September 2019, p. 114458, 2020.
